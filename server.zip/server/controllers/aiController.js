const { extractTextFromPDF } = require("../utils/pdfExtractor");
const { analyzeResume } = require("../services/geminiService");

const analyzeResumeController = async (req, res) => {
  try {
    // Check if a file was uploaded
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "Please upload a resume PDF.",
      });
    }

    // Extract text from the uploaded PDF
    const resumeText = await extractTextFromPDF(req.file.path);

    // Send the extracted text to Gemini
    const analysis = await analyzeResume(resumeText);

    // Gemini returns text, so try to convert it to JSON
    let result;

    try {
      result = JSON.parse(analysis);
    } catch (err) {
      result = {
        rawResponse: analysis,
      };
    }

    res.status(200).json({
      success: true,
      message: "Resume analyzed successfully.",
      analysis: result,
    });

  } catch (error) {
    console.error("AI Controller Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to analyze resume.",
      error: error.message,
    });
  }
};

module.exports = {
  analyzeResumeController,
};