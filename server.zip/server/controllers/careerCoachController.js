const { GoogleGenerativeAI } = require("@google/generative-ai");

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const askCareerCoach = async (req, res) => {
  try {
    const { question } = req.body;

    if (!question) {
      return res.status(400).json({
        success: false,
        message: "Question is required.",
      });
    }

    const model = genAI.getGenerativeModel({
      model: "gemini-1.5-flash",
    });

    const prompt = `
You are an expert AI Career Coach.

Answer professionally and clearly.

User Question:
${question}
`;

    const result = await model.generateContent(prompt);

    const response = result.response.text();

    res.status(200).json({
      success: true,
      answer: response,
    });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: "Failed to get AI response.",
    });
  }
};

module.exports = {
  askCareerCoach,
};