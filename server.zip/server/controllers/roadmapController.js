const { GoogleGenerativeAI } = require("@google/generative-ai");
const Roadmap = require("../models/Roadmap");

// Initialize Gemini
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// ===================================================
// Generate AI Roadmap
// POST /api/roadmap/generate
// ===================================================
const generateRoadmap = async (req, res) => {
  try {
    const { career, level } = req.body;

    if (!career || !level) {
      return res.status(400).json({
        success: false,
        message: "Career and level are required.",
      });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        success: false,
        message: "Gemini API Key is missing in .env",
      });
    }

    const model = genAI.getGenerativeModel({
  model: "gemini-2.5-flash",
});

    const prompt = `
You are an expert career mentor.

Create a professional and detailed learning roadmap.

Career Goal:
${career}

Current Skill Level:
${level}

Generate a structured roadmap including:

1. Month-wise learning plan (6 months)
2. Topics to learn each month
3. Mini Projects
4. Major Project
5. Best Free Courses
6. YouTube Channels
7. Certifications
8. Coding Practice Websites
9. Interview Preparation
10. Expected Skills after completion

Return the roadmap in clean Markdown format.
`;

    const result = await model.generateContent(prompt);

    const response = await result.response;

    const roadmap = response.text();

    if (!roadmap) {
      return res.status(500).json({
        success: false,
        message: "Gemini returned an empty response.",
      });
    }

    const savedRoadmap = await Roadmap.create({
      user: req.user._id,
      career,
      level,
      roadmap,
    });

    res.status(201).json({
      success: true,
      message: "Roadmap generated successfully.",
      roadmap: savedRoadmap.roadmap,
    });

  } catch (error) {

    console.error("========== ROADMAP ERROR ==========");
    console.error(error);
    console.error("===================================");

    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// ===================================================
// Get User Roadmap History
// GET /api/roadmap/history
// ===================================================
const getRoadmapHistory = async (req, res) => {
  try {

    const roadmaps = await Roadmap.find({
      user: req.user._id,
    }).sort({
      createdAt: -1,
    });

    res.status(200).json({
      success: true,
      roadmaps,
    });

  } catch (error) {

    console.error(error);

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }
};

// ===================================================
// Delete Roadmap
// DELETE /api/roadmap/:id
// ===================================================
const deleteRoadmap = async (req, res) => {
  try {

    const roadmap = await Roadmap.findById(req.params.id);

    if (!roadmap) {
      return res.status(404).json({
        success: false,
        message: "Roadmap not found.",
      });
    }

    if (roadmap.user.toString() !== req.user._id.toString()) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized.",
      });
    }

    await roadmap.deleteOne();

    res.status(200).json({
      success: true,
      message: "Roadmap deleted successfully.",
    });

  } catch (error) {

    console.error(error);

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }
};

module.exports = {
  generateRoadmap,
  getRoadmapHistory,
  deleteRoadmap,
};