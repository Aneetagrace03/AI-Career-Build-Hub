const { GoogleGenAI } = require("@google/genai");

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

const analyzeResume = async (resumeText) => {
  try {
    const prompt = `
You are an expert ATS (Applicant Tracking System) and Career Coach.

Analyze the following resume.

Return ONLY valid JSON in this exact format:

{
  "atsScore": number,
  "summary": "string",
  "strengths": [
    "string"
  ],
  "weaknesses": [
    "string"
  ],
  "missingSkills": [
    "string"
  ],
  "suggestions": [
    "string"
  ],
  "interviewQuestions": [
    "string"
  ]
}

Resume:

${resumeText}
`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    return response.text;

  } catch (error) {
    console.error("Gemini Error:", error);

    throw error;
  }
};

module.exports = {
  analyzeResume,
};