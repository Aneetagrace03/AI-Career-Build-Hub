const fs = require("fs");
const pdf = require("pdf-parse");

const extractTextFromPDF = async (filePath) => {
  try {
    // Read the uploaded PDF
    const dataBuffer = fs.readFileSync(filePath);

    // Extract text
    const data = await pdf(dataBuffer);

    return data.text;
  } catch (error) {
    console.error("PDF Extraction Error:", error);
    throw error;
  }
};

module.exports = {
  extractTextFromPDF,
};