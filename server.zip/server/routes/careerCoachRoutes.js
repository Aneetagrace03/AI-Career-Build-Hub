const express = require("express");

const router = express.Router();

const {
  askCareerCoach,
} = require("../controllers/careerCoachController");

router.post("/chat", askCareerCoach);

module.exports = router;